library(testthat)

test_check("gdxtools")
