# gdxtools 0.6.0

* Faster write gdx when only parameters and/or sets using gdxrrw
* Fast write2 gdx function

# gdxtools 0.5.1

* Can write set with one dimension
* Fix writing with sets containing digits with different size
* Allows for space and dots in set names when writing gdx

# gdxtools 0.4.0

* Includes gdxrrw

# gdxtools 0.3.5

* speed up in extract gdx
* gdx compression by default
* add some tests
* handle empty parameter

# gdxtools 0.3.4

* add variables in write.gdx (deal with .l, .lo, .up)

# gdxtools 0.3.3

* add digits in write.gdx to control the precision

# gdxtools 0.2

* Change license to EPL to comply with gdxrrw
* Fix a lot of bugs on the extraction
* Add many tests


# gdxtools 0.1

* first version
