
lahman_dt <- function() {
  dtplyr::src_dt("Lahman")
}
