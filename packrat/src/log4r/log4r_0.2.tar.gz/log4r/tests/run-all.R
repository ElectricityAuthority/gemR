library(testthat)

test_check("log4r")
