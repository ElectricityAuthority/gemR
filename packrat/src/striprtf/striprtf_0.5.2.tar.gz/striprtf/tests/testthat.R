library(testthat)
library(striprtf)

test_check("striprtf")
