library(testthat)
test_check("ndjson")
